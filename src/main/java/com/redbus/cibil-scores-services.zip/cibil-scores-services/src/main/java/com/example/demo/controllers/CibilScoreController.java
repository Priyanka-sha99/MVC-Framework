package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.CibilScore;
import com.example.demo.services.CibilScoreService;

import lombok.Setter;

@RestController
@Setter
public class CibilScoreController {

	@Autowired
	private CibilScoreService service;
	
	@GetMapping(path = "/api/v1/cibilscore")
	public List<CibilScore> getAll(){
		return this.service.findAll();
	}
	
	@PostMapping(path = "/api/v1/cibilscore")
	public CibilScore add(@RequestBody CibilScore entity) {
		return this.service.add(entity);
	}
	
	@PutMapping(path = "/api/v1/cibilscore")
	public CibilScore update(@RequestBody CibilScore entity) {
		return this.service.updateById(entity);
	}
	
	@DeleteMapping(path = "/api/v1/cibilscore")
	public void delete(@RequestBody CibilScore entity) {
		 this.service.delete(entity);
	}
	
}
