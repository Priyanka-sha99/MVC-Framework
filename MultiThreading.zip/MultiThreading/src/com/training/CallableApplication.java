package com.training;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CallableApplication {

	public static void main(String[] args) {
		
		ExecutorService service = Executors.newSingleThreadExecutor();
		
		Factorial fiveFactorial = new Factorial(5);
		
		Future<Integer> future= service.submit(fiveFactorial);
		//System.out.println(future.get());
		Integer result=null;
			try {
				 result = future.get();
				System.out.println(result);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			} catch (ExecutionException e) {
				
				e.printStackTrace();
			}
			
		if(future.isDone()) {
			Long val = new Long(result);
			System.out.println(val);
		}
		
		service.shutdown();
	}

}
