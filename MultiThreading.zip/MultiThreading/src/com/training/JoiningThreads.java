package com.training;

import java.util.Scanner;

public class JoiningThreads {
	
	public static void main(String[] args) {
		
		//System.out.println(Thread.currentThread().getName());
		System.out.println("Main Thread Starts");
		
		Runnable task = () ->{
			System.out.println("joining Thread");
			Scanner sc = new Scanner(System.in);
			System.out.println( "�nter Name:");
			String name =sc.next();
			System.out.println("Join Thread Finished");
		};
		
		Thread thread = new Thread(task);
		thread.start();
		
		try {
			thread.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Main Thread Finished");
		
		
	}

}
