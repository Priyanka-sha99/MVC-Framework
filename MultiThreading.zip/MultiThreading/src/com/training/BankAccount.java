package com.training;

public class BankAccount {

	private double balance = 3000;
	
	public synchronized double deposit(double amount) {
		
		this.balance= this.balance+amount;
		notifyAll();
		return this.balance;
	}
	
	public synchronized double withdraw(double amount)
	{
		System.out.println("withdrawing");
		if(balance < amount)
		{
			System.out.println("�nsuffiecient Balance- Waiting");
			
			try {
				wait();
				
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
		System.out.println("got bal");
		balance = balance - amount;
		return balance;
	}
}
