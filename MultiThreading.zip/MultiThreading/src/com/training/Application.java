package com.training;

public class Application {

	public static void main(String[] args) {
		
		new PrintingTask("Piu", "Shah");
		new PrintingTask("Pizza", "Coke");
		new PrintingTask("Poori", "Bhaji");
		new PrintingTask("Paav", "Bhaji");

	}

}
