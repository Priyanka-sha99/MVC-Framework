package com.training;

public class ThreadCommunicationApplication {

	public static void main(String[] args) {

		BankAccount account1 = new BankAccount();
		
		Runnable task1 = ()->{
			double bal=account1.withdraw(5000);
			System.out.println("Balance after withdraw- "+bal);
		};
		Thread t1 = new Thread(task1);
		t1.start();
		Runnable task2 = ()->{
			double depo = account1.deposit(8000);
			System.out.println("Bal after deposit: " +depo);
		};
		
		
		Thread t2 = new Thread(task2);
		 t2.start();
		
	}

}
